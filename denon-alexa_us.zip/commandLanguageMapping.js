module.exports = function (command){

  if (command == 'volume') return 'volume';
  return '';
};